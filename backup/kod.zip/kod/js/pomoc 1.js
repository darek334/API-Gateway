if(DOM.Data.Body[RowId ].isExceptionalEmpty(['OptionType', DOM.Data.Body[RowId ].OptionType ] ) ){
											
	if(DOM.setOptionType(RowId, HTMLObject.value ) ){
		
		DOM.htmlChangeRow(RowId, HTMLObject.value );
		return true;
	}
}
else if(confirm('Wszystkie pola zostaną wyczyszczone\n\nKontynuować ?!' ) ){
	
	if(DOM.setOptionType(RowId, HTMLObject.value ) ){
		
		DOM.htmlChangeRow(RowId, HTMLObject.value );
		return true;
	}
}
else{
	
	//przywraca starą wartość
	HTMLObject.value = DOM.Data.Body[RowId ].OptionType;
}

return false;